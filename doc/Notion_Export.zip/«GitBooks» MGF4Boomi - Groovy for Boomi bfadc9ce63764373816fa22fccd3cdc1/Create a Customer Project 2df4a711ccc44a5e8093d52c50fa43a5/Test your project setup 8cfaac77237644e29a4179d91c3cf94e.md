# Test your project setup

After setting up your customer project it is time to test the setup.

- Right-click the `\src\src`folder and chosse `New..`
    - Select a **Groovy Script** - not a Groovy class!
        
        ![Untitled](Test%20your%20project%20setup%208cfaac77237644e29a4179d91c3cf94e/Untitled.png)
        
- Edit you code
    
    ![Untitled](Test%20your%20project%20setup%208cfaac77237644e29a4179d91c3cf94e/Untitled%201.png)
    
- Right-Click the groovy file and *Run Hello World* - or press Ctrl+Alt-F5
    
    ![Untitled](Test%20your%20project%20setup%208cfaac77237644e29a4179d91c3cf94e/Untitled%202.png)
    

The build process starts - takes a second or two - then the script is executed by your Java run-time (Groovy is Java):

![Untitled](Test%20your%20project%20setup%208cfaac77237644e29a4179d91c3cf94e/Untitled%203.png)

> Forget about the WARNINGS. They pop-up because of the ancient Groovy version we use.
>