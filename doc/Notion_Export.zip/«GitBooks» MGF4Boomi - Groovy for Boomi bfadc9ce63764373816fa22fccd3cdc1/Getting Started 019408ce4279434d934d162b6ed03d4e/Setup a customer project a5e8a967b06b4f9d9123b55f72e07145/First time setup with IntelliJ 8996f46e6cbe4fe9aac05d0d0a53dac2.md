# First time setup with IntelliJ

With IntelliJ IDEA we have to do a first time setup to tell IntelliJ IDEA about the [Local disk folder structure](../Local%20disk%20folder%20structure%20d010906aac0344bab591f7bebd243856.md) .

- Run IntelliJ IDEA and open your first project
    
    ![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled.png)
    

IntellJ IDEA will complain about not yet knowing the global libraries and SDKs.

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%201.png)

Do not click on these yellow bars, yet. We will setup manually!!!

## Three things to do

1. Configure the JDK
2. Tell IntelliJ IDEA about groovy 2.4.13
3. Tell IntelliJ there are more global libraries: the ATOMSphere libs

### Configure the ATOMSphere JDK

- Open the Module settings or press F4
**Platform Settings** → **SDKs** → **+** → **Add JDK …**

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%202.png)

Actually, we do not need the JDK, the JRE from the ATOM is right for us.

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%203.png)

### **Configure Groovy SDK**

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%204.png)

- **Use Library** → **Create …** → **Choose Grovvy SDK location**

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%205.png)

Close the dialog → **OK** and stop!

A project library can be used only in the current project. However, we want to use the Groovy SDK in all future project without that hazzel of the setup. That why we want to configure it as a global library: once and forever.

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%206.png)

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%207.png)

### Configure the ATOMSphere libraries

In your Project Dialog (**F4**) add a **New Global Library: Java**
`C:\Program Files\Boomi AtomSphere\**LocalAtom\lib**`

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%208.png)

Add it to all Modules

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%209.png)

And, finally, give it a more meaningful name 

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%2010.png)

You are done!

![Untitled](First%20time%20setup%20with%20IntelliJ%208996f46e6cbe4fe9aac05d0d0a53dac2/Untitled%2011.png)