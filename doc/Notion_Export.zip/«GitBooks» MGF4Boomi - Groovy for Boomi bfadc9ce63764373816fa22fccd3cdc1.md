# «GitBooks» MGF4Boomi - Groovy for Boomi

> **MGF4Boomi → M**arkus’ **G**roovy **F**ramework **for** **Boomi**
> 

All you need to create, debug and test Groovy scripts for Boomi Integration.

# Basics

[Getting Started](%C2%ABGitBooks%C2%BB%20MGF4Boomi%20-%20Groovy%20for%20Boomi%20bfadc9ce63764373816fa22fccd3cdc1/Getting%20Started%20019408ce4279434d934d162b6ed03d4e.md)

[Setup Guide](%C2%ABGitBooks%C2%BB%20MGF4Boomi%20-%20Groovy%20for%20Boomi%20bfadc9ce63764373816fa22fccd3cdc1/Setup%20Guide%20cbd6cb0d375246c1b832555fd5ffc131.md)

[Create a Customer Project](%C2%ABGitBooks%C2%BB%20MGF4Boomi%20-%20Groovy%20for%20Boomi%20bfadc9ce63764373816fa22fccd3cdc1/Create%20a%20Customer%20Project%202df4a711ccc44a5e8093d52c50fa43a5.md)

[IntelliJ](%C2%ABGitBooks%C2%BB%20MGF4Boomi%20-%20Groovy%20for%20Boomi%20bfadc9ce63764373816fa22fccd3cdc1/IntelliJ%207ef933f5f8a8444283790d03ea6f5e1e.md)

Markus Schmidt, Jan-2022